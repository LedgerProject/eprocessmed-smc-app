  const  global_functions = {};

  global_functions.messagesSrv = (mss) => {
    console.log(mss);
  };
  
  module.exports =  global_functions;