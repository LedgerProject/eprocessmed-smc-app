export const dataConfig = {
  srvMiddl: {
    host:'<host>',
    port:'<port>'
  },
  srvMiddlTest: {
    host:'<host>',
    port:'<port>'
  },
  srvMiddlDev: {
    host:'<host>',
    port:'<port>'
  },
  http: 'http://',
  https: 'https://',
  environment: 'Development', // Development || Testing || Production
  ssl: false                  // false || true
};

